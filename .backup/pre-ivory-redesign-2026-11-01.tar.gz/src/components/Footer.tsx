import { wedding } from '../config/wedding'
import { Reveal } from './ui/motion'

export function Footer() {
  const { bride, groom, hashtag } = wedding
  return (
    <footer className="relative overflow-hidden bg-wine px-5 pt-28 pb-[calc(3.5rem+env(safe-area-inset-bottom))] text-center text-paper">
      <Reveal>
        <p className="eyebrow !text-paper/60">With all our love</p>
        <p className="mt-6 font-script text-[clamp(4.5rem,14vw,9rem)] leading-[0.9]">Thank you</p>
        <p className="mt-6 font-serif text-2xl font-light italic">for being part of our story</p>
        <p lang="my" className="mt-2 text-paper/75">
          ချစ်ခြင်းမေတ္တာဖြင့် ကျေးဇူးတင်ပါသည်။
        </p>
        <p className="mt-16 font-serif text-4xl font-light">
          {bride.short} <span className="font-script">&amp;</span> {groom.short}
        </p>
        <p className="eyebrow mt-3 !text-paper/60">28 · 11 · 2026 &nbsp;·&nbsp; {hashtag}</p>
      </Reveal>
    </footer>
  )
}
