import { MotionConfig, motion } from 'motion/react'
import { useCallback, useEffect, useState } from 'react'
import { Footer } from './components/Footer'
import { Gallery } from './components/Gallery'
import { Gifts } from './components/Gifts'
import { Hero } from './components/Hero'
import { Invitation } from './components/Invitation'
import { Marquee } from './components/Marquee'
import { Nav } from './components/Nav'
import { Rsvp } from './components/Rsvp'
import { SaveTheDate } from './components/SaveTheDate'
import { Schedule } from './components/Schedule'
import { Story } from './components/Story'
import { Venue } from './components/Venue'
import { useSmoothScroll } from './hooks/useSmoothScroll'
import { Intro } from './intro/Intro'

/**
 * The 3D intro film (three.js) plays first; on the guest's tap the card flies
 * to camera and a light-wash reveals the invitation site beneath.
 */
export default function App() {
  const [opened, setOpened] = useState(false)
  const onOpened = useCallback(() => setOpened(true), [])

  // Keep the page still while the intro is up.
  useEffect(() => {
    document.documentElement.classList.toggle('is-locked', !opened)
  }, [opened])

  useSmoothScroll(opened)

  return (
    <MotionConfig reducedMotion="user">
      {!opened && <Intro onDone={onOpened} />}

      {/* Opacity only: a transform here would turn the fixed nav into a scrolling element. */}
      <motion.div
        className="relative z-20"
        initial={{ opacity: 0 }}
        animate={{ opacity: opened ? 1 : 0 }}
        transition={{ duration: 1.2, delay: 0.6 }}
        inert={!opened}
      >
        <Nav />
      </motion.div>

      <motion.div
        className="relative z-10"
        initial={{ opacity: 0 }}
        animate={{ opacity: opened ? 1 : 0 }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
        inert={!opened}
      >
        <main>
          <Hero revealed={opened} />
          <Marquee />
          <Invitation />
          <SaveTheDate />
          <Story />
          <Gallery />
          <Schedule />
          <Venue />
          <Rsvp />
          <Gifts />
        </main>
        <Footer />
      </motion.div>
    </MotionConfig>
  )
}
