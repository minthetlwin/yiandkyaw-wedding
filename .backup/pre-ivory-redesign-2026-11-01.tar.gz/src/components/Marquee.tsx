import { wedding } from '../config/wedding'

/** Slow, endless band of serif type. Duplicated once so the loop is seamless. */
export function Marquee() {
  const item = (
    <span className="flex shrink-0 items-center gap-10 pr-10 font-serif text-5xl font-light text-ink italic md:text-7xl">
      <span>
        {wedding.bride.short} &amp; {wedding.groom.short}
      </span>
      <span className="font-script text-wine not-italic">♡</span>
      <span>28 · 11 · 2026</span>
      <span className="font-script text-wine not-italic">♡</span>
      <span>Forever begins</span>
      <span className="font-script text-wine not-italic">♡</span>
    </span>
  )
  return (
    <div className="relative overflow-hidden border-y border-ink/10 py-8" aria-hidden="true">
      <div className="animate-marquee flex w-max">
        {item}
        {item}
        {item}
        {item}
      </div>
    </div>
  )
}
