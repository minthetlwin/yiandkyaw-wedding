import { Canvas, useFrame } from '@react-three/fiber'
import { useEffect, useMemo, useRef } from 'react'
import * as THREE from 'three'

/**
 * Real 3D rose petals drifting through the intro: cupped, curled geometry with
 * a velvet sheen, softly lit. Rendered at full device resolution with MSAA and
 * no post-processing, so they stay razor sharp. `gust` lifts them for the open.
 */

function petalGeometry() {
  const s = new THREE.Shape()
  s.moveTo(0, 0)
  s.bezierCurveTo(0.14, 0.05, 0.17, 0.24, 0.025, 0.35)
  s.quadraticCurveTo(0, 0.33, -0.025, 0.35)
  s.bezierCurveTo(-0.17, 0.24, -0.14, 0.05, 0, 0)
  const geo = new THREE.ShapeGeometry(s, 24)
  const p = geo.attributes.position
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i)
    const y = p.getY(i)
    p.setZ(i, x * x * 3 - y * y * 0.7 + Math.sin(y * 9) * 0.006) // cupped, curled tip, soft ripple
  }
  geo.center()
  geo.computeVertexNormals()
  return geo
}

/** Deterministic PRNG: stable layout, pure render. */
function seeded(seed: number) {
  let a = seed >>> 0
  return () => {
    a = (a + 0x6d2b79f5) >>> 0
    let t = Math.imul(a ^ (a >>> 15), a | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

const TONES = ['#f2c3bd', '#e9a7a2', '#f7d9d3', '#dd8f8f', '#fbe7e2'].map((c) => new THREE.Color(c))
const SPAN = { x: 7, y: 5.5 }

function Petals({ count, gust }: { count: number; gust: boolean }) {
  const mesh = useRef<THREE.InstancedMesh>(null)
  const geometry = useMemo(() => petalGeometry(), [])
  const sim = useMemo(() => {
    const r = seeded(count * 977)
    return Array.from({ length: count }, () => ({
      pos: new THREE.Vector3((r() - 0.5) * SPAN.x * 2, (r() - 0.5) * SPAN.y * 2, -r() * 5 + 1.2),
      fall: 0.22 + r() * 0.28,
      sway: 0.25 + r() * 0.5,
      phase: r() * Math.PI * 2,
      axis: new THREE.Vector3(r() - 0.5, r() - 0.5, r() - 0.5).normalize(),
      spin: 0.35 + r() * 0.9,
      scale: 0.65 + r() * 0.6,
      tone: Math.floor(r() * TONES.length),
      lift: 0,
    }))
  }, [count])
  const dummy = useMemo(() => new THREE.Object3D(), [])
  const pointer = useRef({ x: 0, y: 0 })

  useEffect(() => {
    const m = mesh.current
    if (!m) return
    sim.forEach((p, i) => m.setColorAt(i, TONES[p.tone]))
    if (m.instanceColor) m.instanceColor.needsUpdate = true
  }, [sim])

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      pointer.current.x = (e.clientX / window.innerWidth) * 2 - 1
      pointer.current.y = (e.clientY / window.innerHeight) * 2 - 1
    }
    window.addEventListener('pointermove', onMove, { passive: true })
    return () => window.removeEventListener('pointermove', onMove)
  }, [])

  useEffect(() => () => geometry.dispose(), [geometry])

  useFrame(({ clock, camera }, delta) => {
    const m = mesh.current
    if (!m) return
    const dt = Math.min(delta, 1 / 30)
    const t = clock.elapsedTime
    // soft parallax
    camera.position.x += (pointer.current.x * 0.35 - camera.position.x) * (1 - Math.exp(-dt * 2))
    camera.position.y += (-pointer.current.y * 0.2 - camera.position.y) * (1 - Math.exp(-dt * 2))
    camera.lookAt(0, 0, 0)

    sim.forEach((p, i) => {
      p.lift += ((gust ? 2.6 : 0) - p.lift) * (1 - Math.exp(-dt * 1.5))
      p.pos.y += (p.lift - p.fall) * dt
      p.pos.x += (Math.sin(t * 0.7 + p.phase) * p.sway + p.lift * 0.4 * Math.sign(p.pos.x)) * dt
      if (p.pos.y < -SPAN.y) p.pos.y = SPAN.y
      if (p.pos.y > SPAN.y + 1) p.pos.y = -SPAN.y
      dummy.position.copy(p.pos)
      dummy.quaternion.setFromAxisAngle(p.axis, t * p.spin + p.phase)
      dummy.scale.setScalar(p.scale)
      dummy.updateMatrix()
      m.setMatrixAt(i, dummy.matrix)
    })
    m.instanceMatrix.needsUpdate = true
  })

  return (
    <instancedMesh ref={mesh} args={[geometry, undefined, count]} frustumCulled={false}>
      <meshPhysicalMaterial roughness={0.5} sheen={1} sheenColor="#fff0f0" sheenRoughness={0.35} side={THREE.DoubleSide} />
    </instancedMesh>
  )
}

export default function PetalRain({ gust }: { gust: boolean }) {
  const count = useMemo(() => (window.matchMedia('(pointer: coarse)').matches || window.innerWidth < 768 ? 26 : 44), [])
  return (
    <Canvas
      className="!absolute inset-0"
      style={{ pointerEvents: 'none' }}
      dpr={[1, 2]}
      gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
      camera={{ position: [0, 0, 8], fov: 42 }}
    >
      <ambientLight intensity={1.1} color="#fff1ec" />
      <hemisphereLight args={['#fff8f2', '#f1cfc8', 0.9]} />
      <directionalLight position={[3, 5, 4]} intensity={1.8} color="#fff4ea" />
      <directionalLight position={[-4, -2, 2]} intensity={0.5} color="#ffd9d4" />
      <Petals count={count} gust={gust} />
    </Canvas>
  )
}
