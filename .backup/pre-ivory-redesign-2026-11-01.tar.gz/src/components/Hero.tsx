import { motion, useScroll, useTransform, type Variants } from 'motion/react'
import { useRef } from 'react'
import { wedding } from '../config/wedding'
import { HeartIcon } from './Icons'
import { silk } from './ui/variants'

const letters: Variants = {
  hidden: { y: '110%' },
  show: (i: number) => ({ y: '0%', transition: { duration: 1.1, ease: silk, delay: 0.25 + i * 0.06 } }),
}

const rise: Variants = {
  hidden: { opacity: 0, y: 24 },
  show: (d: number) => ({ opacity: 1, y: 0, transition: { duration: 1.2, ease: silk, delay: d } }),
}

/** A word whose letters rise one by one from behind a mask. */
function MaskedWord({ text, offset = 0, className = '' }: { text: string; offset?: number; className?: string }) {
  return (
    <span className={`inline-flex overflow-hidden pb-[0.08em] ${className}`} aria-hidden="true">
      {[...text].map((ch, i) => (
        <motion.span key={i} className="inline-block" variants={letters} custom={offset + i}>
          {ch}
        </motion.span>
      ))}
    </span>
  )
}

/** "Save the date" text seal that slowly rotates around a heart. */
function DateSeal({ className = '' }: { className?: string }) {
  const text = 'SAVE THE DATE · 28 NOVEMBER 2026 · '
  return (
    <div className={`grid size-32 place-items-center rounded-full bg-paper/90 shadow-[var(--shadow-float)] backdrop-blur sm:size-36 ${className}`}>
      <svg viewBox="0 0 120 120" className="animate-spin-slow absolute size-full" aria-hidden="true">
        <defs>
          <path id="seal-circle" d="M60 60m-46 0a46 46 0 1 1 92 0a46 46 0 1 1 -92 0" />
        </defs>
        <text fontFamily="Jost, sans-serif" fontSize="8.4" letterSpacing="2.6" fill="#6e2232">
          <textPath href="#seal-circle">{text}</textPath>
        </text>
      </svg>
      <HeartIcon width={26} height={26} className="text-wine" fill="currentColor" stroke="none" />
    </div>
  )
}

export function Hero({ revealed }: { revealed: boolean }) {
  const { bride, groom, event, venue, story } = wedding
  const ref = useRef<HTMLElement>(null)
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] })
  const imageY = useTransform(scrollYProgress, [0, 1], ['0%', '14%'])
  const photo = story[0].photo

  return (
    <motion.section
      ref={ref}
      id="top"
      aria-label={`${bride.short} and ${groom.short} are getting married`}
      className="relative mx-auto grid min-h-svh max-w-7xl items-center gap-10 px-5 pt-24 pb-16 sm:px-8 md:grid-cols-[1.1fr_0.9fr] md:gap-16"
      initial="hidden"
      animate={revealed ? 'show' : 'hidden'}
    >
      {/* Photo first on phones, right column on desktop. */}
      <motion.div className="relative md:order-2" variants={rise} custom={0.1}>
        <div className="relative mx-auto aspect-[3/4] max-h-[56svh] overflow-hidden rounded-t-full rounded-b-[2rem] shadow-[var(--shadow-float)] md:max-h-[78svh]">
          <motion.img
            src={photo.src}
            alt={photo.alt}
            width={photo.width}
            height={photo.height}
            fetchPriority="high"
            className="h-[114%] w-full object-cover"
            style={{ y: imageY }}
            initial={{ scale: 1.15 }}
            animate={revealed ? { scale: 1 } : { scale: 1.15 }}
            transition={{ duration: 2.4, ease: silk }}
          />
          <div className="pointer-events-none absolute inset-0 rounded-t-full rounded-b-[2rem] ring-1 ring-ink/5 ring-inset" />
        </div>
        <DateSeal className="absolute -bottom-6 left-2 sm:-left-6" />
      </motion.div>

      <div className="text-center md:text-left">
        <motion.p className="eyebrow" variants={rise} custom={0.2}>
          Together with their families
        </motion.p>
        <h1 className="mt-6 font-serif leading-[0.86] font-light tracking-[-0.02em] text-ink">
          <span className="sr-only">
            {bride.short} and {groom.short}
          </span>
          <MaskedWord text={bride.short} className="text-[clamp(5rem,15vw,10.5rem)]" />
          <span className="block font-script text-[clamp(3.6rem,9vw,6.5rem)] leading-[0.7] font-normal tracking-normal text-wine md:pl-[0.4em]" aria-hidden="true">
            <MaskedWord text="&" offset={2} />
          </span>
          <MaskedWord text={groom.short} offset={3} className="text-[clamp(5rem,15vw,10.5rem)] md:pl-[0.5em]" />
        </h1>
        <motion.p className="mt-6 font-serif text-2xl text-muted italic sm:text-3xl" variants={rise} custom={0.9}>
          are getting married
        </motion.p>
        <motion.p lang="my" className="mt-1 text-muted" variants={rise} custom={1}>
          {groom.nameMy} နှင့် {bride.nameMy}
        </motion.p>

        <motion.div className="mt-8 flex items-center justify-center gap-5 md:justify-start" variants={rise} custom={1.1}>
          <span className="h-px w-12 bg-ink/25" aria-hidden="true" />
          <span className="font-serif text-xl tracking-[0.3em] text-ink">28 · 11 · 2026</span>
          <span className="h-px w-12 bg-ink/25" aria-hidden="true" />
        </motion.div>
        <motion.p className="mt-3 text-sm tracking-wide text-muted" variants={rise} custom={1.15}>
          {event.timeLabel} · {venue.name}
        </motion.p>

        <motion.div className="mt-9 flex flex-wrap justify-center gap-3 md:justify-start" variants={rise} custom={1.25}>
          <a href="#rsvp" className="btn btn-primary">
            Kindly RSVP
          </a>
          <a href="#invitation" className="btn btn-ghost">
            Open the card
          </a>
        </motion.div>
      </div>
    </motion.section>
  )
}
