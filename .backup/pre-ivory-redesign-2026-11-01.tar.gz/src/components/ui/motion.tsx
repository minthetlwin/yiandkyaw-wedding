import { motion } from 'motion/react'
import type { ReactNode } from 'react'
import { fadeUp, stagger } from './variants'

const VIEWPORT = { once: true, margin: '0px 0px -12% 0px' } as const

interface RevealProps {
  children: ReactNode
  className?: string
  delay?: number
}

/** Fades and floats its content up the first time it scrolls into view. */
export function Reveal({ children, className, delay = 0 }: RevealProps) {
  return (
    <motion.div
      className={className}
      initial="hidden"
      whileInView="show"
      viewport={VIEWPORT}
      variants={fadeUp}
      transition={{ delay }}
    >
      {children}
    </motion.div>
  )
}

/** Container whose `RevealItem` children animate in one after another. */
export function RevealGroup({ children, className }: Omit<RevealProps, 'delay'>) {
  return (
    <motion.div className={className} initial="hidden" whileInView="show" viewport={VIEWPORT} variants={stagger}>
      {children}
    </motion.div>
  )
}

export function RevealItem({ children, className }: Omit<RevealProps, 'delay'>) {
  return (
    <motion.div className={className} variants={fadeUp}>
      {children}
    </motion.div>
  )
}
