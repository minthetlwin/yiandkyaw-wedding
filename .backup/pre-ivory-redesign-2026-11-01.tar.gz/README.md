# Yi & Kyaw — Wedding Invitation

A luxury digital wedding invitation. Guests arrive to a textured blush
envelope sealed with gold wax; a tap breaks the seal in a burst of stardust,
the flap swings open in 3D to a watercolour floral lining, the card slides out
and the camera pushes in until the card becomes the homepage. The card tilts
with the pointer or phone gyroscope so its gold leaf glistens. Sections: our
story (polaroids), moments, the day's schedule, venue & map, RSVP (with dietary
choices and a live guest counter) and gifts (KBZPay), over a soft three.js
backdrop of golden bokeh and drifting petals.

Stack: React 19 · Tailwind CSS v4 · Motion (Framer Motion) · React Three Fiber · Lenis.

## Develop

```bash
npm install
npm run dev       # http://localhost:5173
npm run build     # type-check + production build into dist/
npm run lint
```

## Edit content

Everything guests see — names, date, time, venue, photos, payment methods — is
in [`src/config/wedding.ts`](src/config/wedding.ts). Photos live in
`public/yiandkyaw/`.

## Shared RSVP counter

Set `VITE_RSVP_ENDPOINT` to a Google Apps Script web app backed by a Google
Sheet. Setup takes about five minutes: see
[`backend/google-apps-script/README.md`](backend/google-apps-script/README.md).
Without it the site still works, but counts are stored per browser only.

## Structure

```
src/
  config/wedding.ts          content (single source of truth): names, date, story, dress code, photos, gifts
  index.css                  Tailwind theme tokens (palette, fonts), paper texture, shared component classes
  lib/rsvp.ts                RSVP service: remote (Google Sheets) or localStorage
  lib/calendar.ts            Google Calendar link, .ics download, map URLs
  hooks/                     countdown, pointer/gyro tilt, smooth scroll, RSVP stats
  components/
    intro/                   envelope intro: wax seal, floral lining, stardust, 3D flap sequence
    card/                    the printed card (shared by envelope and hero) and monogram
    background/              React Three Fiber bokeh + petals backdrop (code-split)
    ui/                      reveal helpers, foil card, polaroid, flourish, line illustration
    *.tsx                    page sections
backend/google-apps-script   Sheets-backed RSVP endpoint
```

## Deploy

Any static host works (Vercel, Netlify, Cloudflare Pages, GitHub Pages). Build
command `npm run build`, output directory `dist`.
