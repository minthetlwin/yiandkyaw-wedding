import { AnimatePresence, motion, stagger, useAnimate } from 'motion/react'
import { lazy, Suspense, useEffect, useRef, useState } from 'react'
import { silk } from '../components/ui/variants'
import { wedding } from '../config/wedding'
import { usePrefersReducedMotion } from '../hooks/hooks'
import { SIGNATURE, SIGNATURE_VIEWBOX } from './signature'

const loadPetals = () => import('./PetalRain')
const PetalRain = lazy(loadPetals)

/** Classic heart, 100 × 90. Used for the photo window mask, the rings and the iris. */
const HEART = 'M50 88C18 66 2 48 2 28 2 12 14 2 28 2c10 0 18 6 22 14C54 8 62 2 72 2c14 0 26 10 26 26 0 20-16 38-48 60Z'
const HEART_MASK = `url("data:image/svg+xml,${encodeURIComponent(`<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 90'><path d='${HEART}'/></svg>`)}")`

const PHOTOS = [wedding.story[0].photo, ...wedding.gallery.filter((p) => p.height > p.width).slice(1, 4)]
const MONTAGE_MS = 2600
const sleep = (ms: number) => new Promise((r) => window.setTimeout(r, ms))

function decode(src: string) {
  const img = new Image()
  img.src = src
  return img.decode().catch(() => undefined)
}

function setMask(el: HTMLElement, size: string, position: string) {
  el.style.maskSize = size
  el.style.setProperty('-webkit-mask-size', size)
  el.style.maskPosition = position
  el.style.setProperty('-webkit-mask-position', position)
}

type Stage = 'playing' | 'ready' | 'opening'

/**
 * "With love, by hand" — the intro.
 *
 *   1  A small wine-red heart appears and beats twice, sending out soft rings.
 *   2  The couple's names write themselves, stroke by stroke, then fill with ink.
 *   3  The heart swells into a window onto their photos (slow Ken Burns, cross-fades).
 *   4  On tap, the heart opens like an iris until the photo fills the screen,
 *      petals lift on a gust of air, and the invitation is revealed.
 *
 * Everything is vector (SVG paths, CSS masks) moved with compositor-friendly
 * transforms, so it stays crisp at any resolution; the 3D petals render at full
 * device pixels with no post-processing.
 */
export function Intro({ onDone }: { onDone: () => void }) {
  const reducedMotion = usePrefersReducedMotion()
  const [scope, animate] = useAnimate<HTMLDivElement>()
  const [stage, setStage] = useState<Stage>('playing')
  const [photo, setPhoto] = useState(0)
  const [gust, setGust] = useState(false)
  const started = useRef(false)

  useEffect(() => {
    if (reducedMotion) onDone()
  }, [reducedMotion, onDone])

  // The film.
  useEffect(() => {
    if (reducedMotion || started.current) return
    started.current = true
    void loadPetals()
    const assets = Promise.all(PHOTOS.map((p) => decode(p.src)))

    const run = async () => {
      await sleep(350)
      // 1 — a heartbeat
      await animate('.heart', { scale: [0, 0.17], opacity: [0, 1] }, { type: 'spring', stiffness: 160, damping: 14 })
      for (const peak of [0.205, 0.195]) {
        animate('.ring', { scale: [0.17, 0.55], opacity: [0.7, 0] }, { duration: 1.2, ease: 'easeOut' })
        await animate('.heart', { scale: [0.17, peak, 0.17] }, { duration: 0.42, ease: 'easeInOut' })
        await sleep(120)
      }

      // 2 — names written by hand
      animate('.eyebrow-intro', { opacity: [0, 1], y: [8, 0] }, { duration: 1, ease: silk })
      animate('.sig', { pathLength: [0, 1], opacity: [0, 1] }, { duration: 0.95, ease: 'easeInOut', delay: stagger(0.26) })
      await animate('.sig', { fillOpacity: [0, 1] }, { duration: 0.8, ease: 'easeOut', delay: stagger(0.26, { startDelay: 0.7 }) })
      animate('.subtitle', { opacity: [0, 1], y: [10, 0], filter: ['blur(6px)', 'blur(0px)'] }, { duration: 1, ease: silk })
      animate('.date-rule', { scaleX: [0, 1] }, { duration: 1.1, ease: silk, delay: 0.25 })
      await animate('.date', { opacity: [0, 1], letterSpacing: ['0.6em', '0.32em'] }, { duration: 1.2, ease: silk, delay: 0.25 })

      // 3 — the heart becomes a window onto their photos
      await assets
      animate('.heart-photo', { opacity: 1 }, { duration: 1.1, ease: 'easeOut', delay: 0.15 })
      await animate('.heart', { scale: 1 }, { type: 'spring', stiffness: 70, damping: 16, mass: 1 })
      setStage('ready')
    }
    void run()
  }, [animate, reducedMotion])

  // Photo montage inside the heart.
  useEffect(() => {
    if (stage === 'playing') return
    const id = window.setInterval(() => setPhoto((p) => (p + 1) % PHOTOS.length), MONTAGE_MS)
    return () => window.clearInterval(id)
  }, [stage])

  async function open() {
    if (stage !== 'ready') return
    setStage('opening')
    setGust(true)
    const box = scope.current.querySelector('.heart')!.getBoundingClientRect()
    const iris = scope.current.querySelector<HTMLElement>('.iris')!
    animate('.copy', { opacity: 0, y: 16, filter: 'blur(6px)' }, { duration: 0.6, ease: 'easeIn' })

    // The iris: a full-screen photo seen through a heart that grows past the screen edges.
    const cx = box.left + box.width / 2
    const cy = box.top + box.height * 0.55
    const end = Math.max(window.innerWidth, window.innerHeight) * 4.5
    setMask(iris, `${box.width}px ${box.height}px`, `${box.left}px ${box.top}px`)
    iris.style.opacity = '1'
    await animate(0, 1, {
      duration: 1.5,
      ease: [0.7, 0, 0.2, 1],
      onUpdate: (k) => {
        const w = box.width + (end - box.width) * k
        const h = w * 0.9
        setMask(iris, `${w}px ${h}px`, `${cx - w / 2}px ${cy - h * 0.55}px`)
      },
    })
    await animate(scope.current, { opacity: 0 }, { duration: 0.8, ease: 'easeOut' })
    onDone()
  }

  if (reducedMotion) return null
  const current = PHOTOS[photo]

  return (
    <div
      ref={scope}
      className="fixed inset-0 z-50 overflow-hidden bg-[radial-gradient(120%_80%_at_50%_30%,#fffaf6_0%,#f8ece6_55%,#f1ddd6_100%)]"
      role="dialog"
      aria-modal="true"
      aria-label="Wedding invitation"
    >
      {/* warm light leak */}
      <div aria-hidden="true" className="pointer-events-none absolute -top-1/4 -right-1/4 size-[80vmax] rounded-full bg-[radial-gradient(closest-side,rgb(255_222_200/0.55),transparent)]" />

      <Suspense fallback={null}>
        <motion.div className="absolute inset-0" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 2 }}>
          <PetalRain gust={gust} />
        </motion.div>
      </Suspense>

      <div className="relative flex h-full flex-col items-center justify-center px-6 pt-[env(safe-area-inset-top)] pb-[env(safe-area-inset-bottom)]">
        <p className="eyebrow-intro eyebrow copy mb-5 opacity-0 sm:mb-7">Together with their families</p>

        {/* the heart: beats small, then becomes a window onto their photos */}
        <div className="relative aspect-[10/9] w-[min(64vw,44svh,400px)]">
          <svg viewBox="0 0 100 90" className="ring pointer-events-none absolute inset-0 overflow-visible opacity-0" aria-hidden="true">
            <path d={HEART} fill="none" stroke="#9a4b58" strokeWidth="1.2" vectorEffect="non-scaling-stroke" />
          </svg>
          <div
            className="heart absolute inset-0 opacity-0"
            style={{ scale: 0, maskImage: HEART_MASK, WebkitMaskImage: HEART_MASK, maskSize: '100% 100%', WebkitMaskSize: '100% 100%' }}
          >
            <div className="absolute inset-0 bg-[radial-gradient(70%_70%_at_35%_30%,#ab4a5e_0%,#7a2638_55%,#5c1a29_100%)]" />
            <div className="heart-photo absolute inset-0 opacity-0">
              <AnimatePresence initial={false}>
                <motion.img
                  key={current.src}
                  src={current.src}
                  alt={current.alt}
                  className="absolute inset-0 h-full w-full object-cover"
                  initial={{ opacity: 0, scale: 1.12 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ opacity: { duration: 1.2 }, scale: { duration: MONTAGE_MS / 1000 + 1.4, ease: 'linear' } }}
                />
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* names, hand-written */}
        <svg viewBox={SIGNATURE_VIEWBOX} className="copy mt-6 w-[min(80vw,540px)] overflow-visible sm:mt-8" role="img" aria-label={`${wedding.bride.short} and ${wedding.groom.short}`}>
          {SIGNATURE.map((g, i) => (
            <motion.path
              key={i}
              className="sig"
              d={g.d}
              initial={{ pathLength: 0, opacity: 0, fillOpacity: 0 }}
              fill={g.group === 'amp' ? '#b8862f' : '#6e2232'}
              stroke={g.group === 'amp' ? '#b8862f' : '#6e2232'}
              strokeWidth={1.6}
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          ))}
        </svg>

        <p className="subtitle copy mt-2 font-serif text-2xl text-muted italic opacity-0 sm:text-3xl">are getting married</p>
        <div className="copy mt-4 flex items-center gap-4">
          <span className="date-rule h-px w-10 origin-right scale-x-0 bg-ink/30 sm:w-14" />
          <span className="date font-serif text-lg text-ink opacity-0 sm:text-xl">28 · 11 · 2026</span>
          <span className="date-rule h-px w-10 origin-left scale-x-0 bg-ink/30 sm:w-14" />
        </div>

        <div className="copy mt-8 h-14">
          <AnimatePresence>
            {stage === 'ready' && (
              <motion.button
                type="button"
                autoFocus
                onClick={() => void open()}
                className="inline-flex items-center gap-3 rounded-full bg-wine px-7 py-4 text-[0.7rem] font-medium tracking-[0.3em] text-paper uppercase shadow-[0_18px_40px_-16px_rgb(110_34_50/0.8)]"
                initial={{ opacity: 0, y: 14, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0 }}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                transition={{ type: 'spring', stiffness: 220, damping: 20 }}
              >
                <motion.span animate={{ scale: [1, 1.25, 1] }} transition={{ duration: 1.2, repeat: Infinity }} aria-hidden="true">
                  ♥
                </motion.span>
                Open our invitation
              </motion.button>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* the iris: full-screen photo revealed through a growing heart */}
      <div
        aria-hidden="true"
        className="iris pointer-events-none absolute inset-0 opacity-0"
        style={{ maskImage: HEART_MASK, WebkitMaskImage: HEART_MASK, maskRepeat: 'no-repeat', WebkitMaskRepeat: 'no-repeat', maskSize: '0px 0px' }}
      >
        <img src={current.src} alt="" className="h-full w-full object-cover" />
      </div>

      <button
        type="button"
        onClick={onDone}
        className="absolute top-[max(16px,env(safe-area-inset-top))] right-4 rounded-full border border-ink/10 bg-paper/60 px-4 py-2 text-[0.62rem] tracking-[0.28em] text-muted uppercase backdrop-blur transition-colors hover:text-ink"
      >
        Skip
      </button>
    </div>
  )
}
