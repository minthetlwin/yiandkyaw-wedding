import { motion } from 'motion/react'
import { wedding } from '../config/wedding'
import { SectionHeading } from './ui/Heading'
import { Reveal } from './ui/motion'
import { silk } from './ui/variants'

/** The day as an elegant vertical timeline; the line draws itself on scroll. */
export function Schedule() {
  return (
    <section id="schedule" aria-labelledby="schedule-title" className="relative scroll-mt-16 bg-paper px-5 py-28 sm:px-8 md:py-36">
      <div className="mx-auto max-w-4xl">
        <SectionHeading id="schedule-title" index="05" eyebrow="Schedule of events" title="The" accent="day" titleMy="အစီအစဉ်" />
        <ol className="relative m-0 list-none p-0">
          <motion.span
            aria-hidden="true"
            className="absolute top-2 bottom-2 left-[5.5rem] w-px origin-top bg-gradient-to-b from-gold via-wine/40 to-gold sm:left-[8.5rem]"
            initial={{ scaleY: 0 }}
            whileInView={{ scaleY: 1 }}
            viewport={{ once: true, margin: '0px 0px -20% 0px' }}
            transition={{ duration: 2.2, ease: 'easeInOut' }}
          />
          {wedding.schedule.map((item, i) => (
            <li key={item.title} className="relative grid grid-cols-[5.5rem_1fr] gap-8 pb-14 last:pb-0 sm:grid-cols-[8.5rem_1fr] sm:gap-12">
              <Reveal delay={i * 0.08}>
                <p className="text-right font-serif text-3xl leading-none font-light text-ink sm:text-5xl">{item.time.split(' ')[0]}</p>
                <p className="eyebrow mt-1 text-right">{item.time.split(' ')[1]}</p>
              </Reveal>
              <motion.span
                aria-hidden="true"
                className="absolute top-3 left-[5.5rem] size-3 -translate-x-1/2 rotate-45 border border-wine bg-paper sm:left-[8.5rem]"
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, ease: silk, delay: 0.3 + i * 0.15 }}
              />
              <Reveal delay={0.1 + i * 0.08}>
                <h3 className="font-serif text-3xl font-light text-ink sm:text-4xl">{item.title}</h3>
                <p lang="my" className="text-wine">
                  {item.titleMy}
                </p>
                <p className="mt-2 max-w-md font-serif text-xl leading-relaxed text-muted">{item.text}</p>
              </Reveal>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
