import type { ReactNode } from 'react'
import { Reveal } from './motion'

interface SectionHeadingProps {
  id: string
  index: string
  eyebrow: string
  /** Serif part of the title. */
  title: string
  /** Script accent appended in wine. */
  accent?: string
  titleMy?: string
  align?: 'center' | 'left'
  children?: ReactNode
}

/** Editorial section heading: number + small caps, large serif with a script accent. */
export function SectionHeading({ id, index, eyebrow, title, accent, titleMy, align = 'center', children }: SectionHeadingProps) {
  const center = align === 'center'
  return (
    <Reveal className={`mb-14 md:mb-20 ${center ? 'text-center' : ''}`}>
      <p className={`eyebrow flex items-center gap-4 ${center ? 'justify-center' : ''}`}>
        <span className="font-serif text-sm tracking-normal text-wine italic">{index}</span>
        <span className="h-px w-10 bg-ink/20" aria-hidden="true" />
        {eyebrow}
      </p>
      <h2 id={id} className="mt-5 font-serif text-5xl leading-[1.02] font-light text-ink sm:text-6xl md:text-7xl">
        {title} {accent && <span className="font-script text-[1.1em] font-normal text-wine">{accent}</span>}
      </h2>
      {titleMy && (
        <p lang="my" className="mt-3 text-muted">
          {titleMy}
        </p>
      )}
      {children}
    </Reveal>
  )
}
