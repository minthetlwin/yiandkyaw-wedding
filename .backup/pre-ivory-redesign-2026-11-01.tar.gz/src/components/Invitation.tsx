import { motion } from 'motion/react'
import { useState } from 'react'
import { wedding } from '../config/wedding'
import { useCountdown } from '../hooks/hooks'
import { SectionHeading } from './ui/Heading'
import { Reveal } from './ui/motion'
import { silk } from './ui/variants'

const UNITS = [
  ['days', 'Days', 'ရက်'],
  ['hours', 'Hours', 'နာရီ'],
  ['minutes', 'Minutes', 'မိနစ်'],
  ['seconds', 'Seconds', 'စက္ကန့်'],
] as const

const face = 'absolute inset-0 overflow-hidden rounded-[1.4rem] bg-paper shadow-[var(--shadow-float)] [backface-visibility:hidden]'

/** Fine double border used on both card faces. */
function CardBorder() {
  return (
    <>
      <span className="pointer-events-none absolute inset-3 rounded-[1rem] border border-gold/60" aria-hidden="true" />
      <span className="pointer-events-none absolute inset-[18px] rounded-[0.8rem] border border-gold/30" aria-hidden="true" />
    </>
  )
}

/** A printed invitation you can turn over: monogram front, full wording on the back. */
function FlipCard() {
  const [flipped, setFlipped] = useState(false)
  const { bride, groom, event, venue } = wedding

  return (
    <div className="mx-auto w-full max-w-[26rem] [perspective:1600px]">
      <motion.button
        type="button"
        onClick={() => setFlipped((f) => !f)}
        aria-label={flipped ? 'Turn the card to the front' : 'Turn the card over to read the invitation'}
        aria-pressed={flipped}
        className="relative block aspect-[5/7] w-full cursor-pointer border-0 bg-transparent p-0 text-left [transform-style:preserve-3d]"
        animate={{ rotateY: flipped ? 180 : 0 }}
        whileHover={{ rotateY: flipped ? 176 : 4, rotateX: 2 }}
        transition={{ duration: 1.1, ease: silk }}
      >
        {/* front */}
        <div className={`${face} grid place-items-center text-center`}>
          <CardBorder />
          <div>
            <p className="eyebrow !text-[0.6rem]">The wedding of</p>
            <p className="mt-6 font-serif text-[5.5rem] leading-[0.85] font-light text-ink">{bride.short}</p>
            <p className="font-script text-6xl leading-[0.8] text-wine">&amp;</p>
            <p className="font-serif text-[5.5rem] leading-[0.85] font-light text-ink">{groom.short}</p>
            <p className="mt-8 font-serif text-lg tracking-[0.3em] text-muted">28 · 11 · 2026</p>
            <p className="eyebrow mt-10 !text-[0.58rem] !text-wine">Tap to turn over ↻</p>
          </div>
        </div>
        {/* back */}
        <div className={`${face} grid place-items-center px-9 text-center [transform:rotateY(180deg)]`}>
          <CardBorder />
          <div>
            <p className="eyebrow !text-[0.58rem]">Together with their families</p>
            <p className="mt-5 font-serif text-xl leading-snug text-ink italic">
              {groom.name}
              <span className="block font-script text-4xl text-wine not-italic">&amp;</span>
              {bride.name}
            </p>
            <p className="mt-4 font-serif text-base leading-relaxed text-muted">
              request the honour of your presence as they celebrate their marriage
            </p>
            <p lang="my" className="mt-3 text-[0.82rem] leading-relaxed text-muted">
              မင်္ဂလာဆောင်ပွဲသို့ ကြွရောက်ချီးမြှင့်ပေးကြပါရန် လေးစားစွာ ဖိတ်ကြားအပ်ပါသည်။
            </p>
            <div className="mx-auto my-5 h-px w-16 bg-gold/60" />
            <p className="font-serif text-lg tracking-[0.18em] text-ink uppercase">{event.dateLabel}</p>
            <p className="mt-1 text-sm text-muted">{event.timeLabel}</p>
            <p className="mt-3 font-serif text-lg text-ink italic">{venue.name}</p>
            <p className="text-xs text-muted">{venue.address}</p>
          </div>
        </div>
      </motion.button>
    </div>
  )
}

export function Invitation() {
  const countdown = useCountdown(wedding.event.start)
  return (
    <section id="invitation" aria-labelledby="invitation-title" className="relative scroll-mt-16 px-5 py-28 sm:px-8 md:py-36">
      <div className="mx-auto grid max-w-6xl items-center gap-16 md:grid-cols-2">
        <Reveal>
          <FlipCard />
        </Reveal>
        <div>
          <SectionHeading id="invitation-title" index="01" eyebrow="The invitation" title="You are" accent="invited" align="left" titleMy="ဖိတ်ကြားလွှာ" />
          <Reveal>
            <p className="max-w-md font-serif text-2xl leading-relaxed text-muted">
              With joyful hearts, we invite you to share in the day we promise each other forever. Turn the card to read it.
            </p>
          </Reveal>
          <Reveal className="mt-12" delay={0.1}>
            <p className="eyebrow">Counting down</p>
            {countdown.done ? (
              <p className="mt-4 font-script text-5xl text-wine">Today is the day ♡</p>
            ) : (
              <dl className="mt-4 grid max-w-md grid-cols-4 divide-x divide-ink/10 border-y border-ink/10" aria-label="Time until the wedding">
                {UNITS.map(([key, label, labelMy]) => (
                  <div key={key} className="flex flex-col-reverse items-center py-5">
                    {/* dt must precede dd; flex-col-reverse shows the number first */}
                    <dt className="mt-1 grid text-center text-[0.58rem] tracking-[0.2em] text-muted uppercase">
                      {label}
                      <span lang="my" className="text-[0.7rem] tracking-normal normal-case">
                        {labelMy}
                      </span>
                    </dt>
                    <dd className="m-0 font-serif text-5xl font-light text-ink tabular-nums">{String(countdown[key]).padStart(2, '0')}</dd>
                  </div>
                ))}
              </dl>
            )}
          </Reveal>
        </div>
      </div>
    </section>
  )
}
