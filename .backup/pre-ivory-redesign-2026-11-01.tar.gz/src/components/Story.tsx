import { motion, useScroll, useTransform } from 'motion/react'
import { useEffect, useRef, useState } from 'react'
import { wedding, type Person, type StoryChapter } from '../config/wedding'
import { SectionHeading } from './ui/Heading'

/** The couple slide: two portraits with names and parents. */
function CoupleSlide() {
  const people: Person[] = [wedding.groom, wedding.bride]
  return (
    <article className="flex w-[min(86vw,940px)] shrink-0 snap-center flex-col justify-end">
      <div className="grid grid-cols-2 gap-4 sm:gap-8">
        {people.map((p) => (
          <figure key={p.name} className="m-0">
            <div className="aspect-[4/5] overflow-hidden rounded-t-full rounded-b-2xl bg-blush">
              <img
                src={p.portrait.src}
                alt={p.portrait.alt}
                width={p.portrait.width}
                height={p.portrait.height}
                loading="lazy"
                decoding="async"
                style={{ objectPosition: p.portrait.focus }}
                className="h-full w-full object-cover"
              />
            </div>
            <figcaption className="mt-5">
              <p className="eyebrow">
                {p.role} · <span lang="my">{p.roleMy}</span>
              </p>
              <p className="mt-2 font-serif text-2xl text-ink sm:text-3xl">{p.name}</p>
              <p lang="my" className="text-sm text-wine">
                {p.nameMy}
              </p>
              {p.parentsMy && (
                <p lang="my" className="text-xs text-muted sm:text-sm">
                  {p.parentsMy}
                </p>
              )}
            </figcaption>
          </figure>
        ))}
      </div>
    </article>
  )
}

function ChapterSlide({ chapter, index }: { chapter: StoryChapter; index: number }) {
  return (
    <article className="grid w-[min(86vw,1000px)] shrink-0 snap-center items-end gap-6 md:grid-cols-[auto_1fr] md:gap-12">
      <div className="h-[52svh] max-h-[620px] overflow-hidden rounded-[1.6rem] md:h-[64svh]">
        <img
          src={chapter.photo.src}
          alt={chapter.photo.alt}
          width={chapter.photo.width}
          height={chapter.photo.height}
          loading="lazy"
          decoding="async"
          className="aspect-[4/5] h-full w-auto max-w-full object-cover"
        />
      </div>
      <div className="pb-2">
        <p className="font-serif text-7xl leading-none font-light text-transparent [-webkit-text-stroke:1px_var(--color-wine)] md:text-8xl">
          {String(index + 1).padStart(2, '0')}
        </p>
        <h3 className="mt-4 font-serif text-4xl leading-tight font-light text-ink md:text-5xl">{chapter.title}</h3>
        <p lang="my" className="mt-2 text-wine">
          {chapter.titleMy}
        </p>
        <p className="mt-4 max-w-sm font-serif text-xl leading-relaxed text-muted">{chapter.text}</p>
      </div>
    </article>
  )
}

/**
 * "Our story" as a film strip. On wide screens the section pins and vertical
 * scroll drives a horizontal pan; on phones it's a native swipe carousel.
 */
export function Story() {
  const pinRef = useRef<HTMLDivElement>(null)
  const trackRef = useRef<HTMLDivElement>(null)
  const [distance, setDistance] = useState(0)
  const [wide, setWide] = useState(() => window.matchMedia('(min-width: 768px)').matches)
  const { scrollYProgress } = useScroll({ target: pinRef, offset: ['start start', 'end end'] })
  const x = useTransform(scrollYProgress, [0, 1], [0, -distance])

  useEffect(() => {
    const mq = window.matchMedia('(min-width: 768px)')
    const onChange = () => setWide(mq.matches)
    mq.addEventListener('change', onChange)
    const track = trackRef.current
    if (!track) return () => mq.removeEventListener('change', onChange)
    const measure = () => setDistance(Math.max(0, track.scrollWidth - window.innerWidth))
    const ro = new ResizeObserver(measure)
    ro.observe(track)
    measure()
    return () => {
      ro.disconnect()
      mq.removeEventListener('change', onChange)
    }
    // Re-measure when the layout switches: the track element is a different node.
  }, [wide])

  const slides = (
    <>
      <CoupleSlide />
      {wedding.story.map((c, i) => (
        <ChapterSlide key={c.title} chapter={c} index={i} />
      ))}
    </>
  )

  return (
    <section id="story" aria-labelledby="story-title" className="relative scroll-mt-16">
      <div className="px-5 pt-28 sm:px-8 md:pt-36">
        <div className="mx-auto max-w-6xl">
          <SectionHeading id="story-title" index="03" eyebrow="Our story" title="A love" accent="story" titleMy="ကျွန်ုပ်တို့၏ ချစ်ခြင်းဇာတ်လမ်း" />
        </div>
      </div>

      {wide ? (
        <div ref={pinRef} style={{ height: `calc(${distance}px + 100svh)` }} className="relative">
          <div className="sticky top-0 flex h-svh flex-col justify-center overflow-hidden">
            <motion.div ref={trackRef} style={{ x }} className="flex w-max gap-24 pr-[8vw] pl-[8vw]">
              {slides}
            </motion.div>
            <div className="mx-auto mt-10 h-px w-[min(60vw,520px)] bg-ink/10">
              <motion.div className="h-full origin-left bg-wine" style={{ scaleX: scrollYProgress }} />
            </div>
          </div>
        </div>
      ) : (
        <div ref={trackRef} className="flex snap-x snap-mandatory gap-8 overflow-x-auto px-[7vw] pb-24 [scrollbar-width:none]">
          {slides}
        </div>
      )}
    </section>
  )
}
