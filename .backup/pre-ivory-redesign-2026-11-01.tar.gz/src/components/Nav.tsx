import { useEffect, useState } from 'react'
import { wedding } from '../config/wedding'

const LINKS = [
  { href: '#invitation', label: 'Invitation' },
  { href: '#story', label: 'Our Story' },
  { href: '#schedule', label: 'The Day' },
  { href: '#venue', label: 'Venue' },
  { href: '#gifts', label: 'Gifts' },
] as const

export function Nav() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={`fixed inset-x-0 top-0 z-40 pt-[env(safe-area-inset-top)] transition-all duration-500 ${
        scrolled ? 'bg-ivory/80 shadow-[0_1px_0_rgb(36_27_26/0.08)] backdrop-blur-xl' : ''
      }`}
    >
      <nav className="mx-auto flex h-16 max-w-6xl items-center gap-8 px-5 sm:px-8" aria-label="Sections">
        <a href="#top" className="font-script text-3xl text-wine no-underline" aria-label="Back to top">
          {wedding.monogram}
        </a>
        <ul className="ml-auto hidden list-none gap-8 md:flex">
          {LINKS.map((l) => (
            <li key={l.href}>
              <a href={l.href} className="eyebrow !tracking-[0.28em] !text-muted no-underline transition-colors hover:!text-ink">
                {l.label}
              </a>
            </li>
          ))}
        </ul>
        <a href="#rsvp" className="btn btn-ghost ml-auto !min-h-0 !px-5 !py-2.5 md:ml-0">
          RSVP
        </a>
      </nav>
    </header>
  )
}
